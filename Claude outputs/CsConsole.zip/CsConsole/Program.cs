using System.Diagnostics;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Scripting;
using Microsoft.CodeAnalysis.CSharp.Scripting.Hosting;
using Microsoft.CodeAnalysis.Scripting;

namespace CsConsole;

/// <summary>Fonctions disponibles directement dans le code C# tapé dans la console.</summary>
public class Globals
{
    /// <summary>Exécute une commande cmd et renvoie sa sortie (stdout + stderr).</summary>
    public string Cmd(string command) => Shell.Capture(command);

    /// <summary>Exécute une commande cmd en affichant sa sortie en direct ; renvoie le code de sortie.</summary>
    public int Sh(string command) => Shell.Run(command);

    /// <summary>Change le dossier courant (partagé avec les commandes cmd).</summary>
    public string Cd(string path)
    {
        Environment.CurrentDirectory = Path.GetFullPath(Environment.ExpandEnvironmentVariables(path));
        return Environment.CurrentDirectory;
    }

    /// <summary>Arguments passés après le nom du script (CsConsole.exe script.csx a b c).</summary>
    public string[] Args { get; set; } = Array.Empty<string>();
}

internal static class Shell
{
    private static readonly Regex CdRegex = new(@"^\s*(cd|chdir)(\s+/d)?\s*(?<path>.*)$", RegexOptions.IgnoreCase);
    private static readonly Regex DriveRegex = new(@"^\s*(?<drive>[a-zA-Z]:)\s*$");

    private static ProcessStartInfo Start(string command) => new("cmd.exe", $"/d /s /c \"{command}\"")
    {
        UseShellExecute = false,
        WorkingDirectory = Environment.CurrentDirectory,
    };

    /// <summary>
    /// Lance une commande cmd dans la console actuelle (couleurs, saisie et Ctrl+C fonctionnent comme dans cmd).
    /// `cd`, `cd /d` et `X:` changent le dossier de la console elle-même, sinon ils seraient perdus à la fin du processus.
    /// </summary>
    public static int Run(string command)
    {
        if (TryChangeDirectory(command)) return 0;
        if (command.Trim().Equals("cls", StringComparison.OrdinalIgnoreCase)) { Console.Clear(); return 0; }
        using var process = Process.Start(Start(command))!;
        process.WaitForExit();
        return process.ExitCode;
    }

    /// <summary>Lance une commande cmd et renvoie sa sortie au lieu de l'afficher.</summary>
    public static string Capture(string command)
    {
        if (TryChangeDirectory(command)) return Environment.CurrentDirectory;
        var info = Start(command);
        info.RedirectStandardOutput = true;
        info.RedirectStandardError = true;
        info.StandardOutputEncoding = Console.OutputEncoding;
        info.StandardErrorEncoding = Console.OutputEncoding;
        using var process = Process.Start(info)!;
        var stderr = process.StandardError.ReadToEndAsync();
        var stdout = process.StandardOutput.ReadToEnd();
        process.WaitForExit();
        return stdout + stderr.Result;
    }

    private static bool TryChangeDirectory(string command)
    {
        var drive = DriveRegex.Match(command);
        if (drive.Success)
        {
            Environment.CurrentDirectory = drive.Groups["drive"].Value + "\\";
            return true;
        }
        var cd = CdRegex.Match(command);
        if (!cd.Success) return false;
        var path = cd.Groups["path"].Value.Trim().Trim('"');
        if (path.Length == 0) { Console.WriteLine(Environment.CurrentDirectory); return true; }
        var target = Path.GetFullPath(Environment.ExpandEnvironmentVariables(path), Environment.CurrentDirectory);
        if (!Directory.Exists(target))
        {
            Program.WriteColor($"Le chemin d'accès spécifié est introuvable : {target}", ConsoleColor.Red);
            return true;
        }
        Environment.CurrentDirectory = target;
        return true;
    }
}

internal static class Program
{
    private static readonly string[] Imports =
    {
        "System", "System.IO", "System.Linq", "System.Text", "System.Collections.Generic", "System.Threading",
        "System.Threading.Tasks", "System.Diagnostics", "System.Net.Http", "System.Text.RegularExpressions",
    };

    private static ScriptState<object>? _state;
    private static CancellationTokenSource? _running;
    private static readonly Globals TheGlobals = new();
    private static bool _cmdMode;

    private static int Main(string[] args)
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;
        Console.Title = "CsConsole — C# et cmd";
        Console.CancelKeyPress += (_, e) =>
        {
            // Ctrl+C arrête le code C# en cours sans fermer la console (les commandes cmd le reçoivent directement).
            if (_running is { IsCancellationRequested: false })
            {
                e.Cancel = true;
                _running.Cancel();
            }
        };

        try
        {
            if (args.Length >= 2 && args[0] is "-c" or "/c") return RunCode(string.Join(' ', args[1..])) ? 0 : 1;
            if (args.Length >= 2 && args[0] is "-cmd" or "/cmd") return Shell.Run(string.Join(' ', args[1..]));
            if (args.Length >= 1 && args[0] is "-h" or "/?" or "--help") { PrintHelp(); return 0; }
            if (args.Length >= 1)
            {
                TheGlobals.Args = args[1..];
                return RunFile(args[0]) ? 0 : 1;
            }
            Repl();
            return 0;
        }
        catch (Exception e)
        {
            WriteColor($"Erreur fatale : {e.Message}", ConsoleColor.Red);
            return 1;
        }
    }

    private static void Repl()
    {
        WriteColor("CsConsole — tape du C# directement, ou une commande cmd précédée de « ! » (ex. !dir).", ConsoleColor.Cyan);
        WriteColor("« :help » pour l'aide, « :exit » pour quitter.\n", ConsoleColor.DarkGray);

        var buffer = new StringBuilder();
        while (true)
        {
            var prompt = buffer.Length > 0 ? "...> " : _cmdMode ? $"{Environment.CurrentDirectory}> " : "cs> ";
            WriteColor(prompt, _cmdMode ? ConsoleColor.Yellow : ConsoleColor.Green, newLine: false);
            var line = Console.ReadLine();
            if (line is null) break; // Ctrl+Z ou fin de l'entrée

            if (buffer.Length == 0)
            {
                var trimmed = line.Trim();
                if (trimmed.Length == 0) continue;
                if (trimmed.StartsWith(':'))
                {
                    if (!Command(trimmed)) break;
                    continue;
                }
                if (trimmed.StartsWith('!')) { Shell.Run(trimmed[1..]); continue; }
                if (_cmdMode) { Shell.Run(line); continue; }
            }

            // C# : on accumule les lignes tant que l'instruction n'est pas complète ; une ligne vide force l'exécution.
            buffer.AppendLine(line);
            var code = buffer.ToString();
            if (line.Trim().Length > 0 && !IsComplete(code)) continue;
            buffer.Clear();
            RunCode(code);
        }
    }

    /// <summary>Commandes de la console (« :… »). Renvoie false pour quitter.</summary>
    private static bool Command(string input)
    {
        var parts = input.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries);
        var arg = parts.Length > 1 ? parts[1].Trim().Trim('"') : "";
        switch (parts[0].ToLowerInvariant())
        {
            case ":exit" or ":quit" or ":q":
                return false;
            case ":help" or ":h" or ":?":
                PrintHelp();
                break;
            case ":cmd":
                _cmdMode = true;
                WriteColor("Mode cmd : chaque ligne est une commande Windows. « :cs » pour revenir au C#.", ConsoleColor.DarkGray);
                break;
            case ":cs":
                _cmdMode = false;
                WriteColor("Mode C#.", ConsoleColor.DarkGray);
                break;
            case ":reset":
                _state = null;
                WriteColor("Variables C# effacées.", ConsoleColor.DarkGray);
                break;
            case ":run" or ":load":
                if (arg.Length == 0) WriteColor("Usage : :run chemin\\script.csx", ConsoleColor.Red);
                else RunFile(arg);
                break;
            case ":vars":
                if (_state is null || _state.Variables.IsEmpty) WriteColor("Aucune variable.", ConsoleColor.DarkGray);
                else
                    foreach (var v in _state.Variables.GroupBy(v => v.Name).Select(g => g.Last()))
                        Console.WriteLine($"{v.Type.Name} {v.Name} = {Format(v.Value)}");
                break;
            case ":clear" or ":cls":
                Console.Clear();
                break;
            default:
                WriteColor($"Commande inconnue : {parts[0]} (tape :help)", ConsoleColor.Red);
                break;
        }
        return true;
    }

    private static bool RunFile(string path)
    {
        var full = Path.GetFullPath(path);
        if (!File.Exists(full))
        {
            WriteColor($"Fichier introuvable : {full}", ConsoleColor.Red);
            return false;
        }
        var code = File.ReadAllText(full);
        // Fichiers .bat / .cmd : exécutés par cmd ; tout le reste est lu comme du C#.
        if (full.EndsWith(".bat", StringComparison.OrdinalIgnoreCase) || full.EndsWith(".cmd", StringComparison.OrdinalIgnoreCase))
            return Shell.Run($"\"{full}\"") == 0;
        return RunCode(code, full);
    }

    private static bool RunCode(string code, string? filePath = null)
    {
        _running = new CancellationTokenSource();
        try
        {
            var options = Options(filePath);
            var task = _state is null
                ? CSharpScript.RunAsync(code, options, TheGlobals, typeof(Globals), _running.Token)
                : _state.ContinueWithAsync(code, options, _running.Token);
            _state = task.GetAwaiter().GetResult();
            if (_state.ReturnValue is not null) WriteColor(Format(_state.ReturnValue), ConsoleColor.White);
            return true;
        }
        catch (CompilationErrorException e)
        {
            foreach (var d in e.Diagnostics) WriteColor(d.ToString(), ConsoleColor.Red);
            return false;
        }
        catch (OperationCanceledException)
        {
            WriteColor("Interrompu.", ConsoleColor.DarkYellow);
            return false;
        }
        catch (Exception e)
        {
            var inner = e is TargetInvocationException or AggregateException && e.InnerException is not null ? e.InnerException : e;
            WriteColor($"{inner.GetType().Name} : {inner.Message}", ConsoleColor.Red);
            return false;
        }
        finally
        {
            _running.Dispose();
            _running = null;
        }
    }

    private static ScriptOptions Options(string? filePath)
    {
        var options = ScriptOptions.Default
            .WithImports(Imports)
            .WithReferences(References())
            .WithLanguageVersion(LanguageVersion.Latest)
            .WithAllowUnsafe(true)
            .WithEmitDebugInformation(true);
        if (filePath is not null)
        {
            var dir = Path.GetDirectoryName(filePath)!;
            options = options
                .WithFilePath(filePath)
                .WithSourceResolver(ScriptSourceResolver.Default.WithBaseDirectory(dir))
                .WithMetadataResolver(ScriptMetadataResolver.Default.WithBaseDirectory(dir));
        }
        return options;
    }

    private static List<MetadataReference>? _references;

    /// <summary>Toutes les bibliothèques .NET disponibles, pour que le code tapé puisse les utiliser sans `#r`.</summary>
    private static List<MetadataReference> References()
    {
        if (_references is not null) return _references;
        var paths = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        if (AppContext.GetData("TRUSTED_PLATFORM_ASSEMBLIES") is string tpa)
            foreach (var p in tpa.Split(Path.PathSeparator)) if (p.Length > 0) paths.Add(p);
        // Exe autonome : les DLL extraites au lancement, et celles déjà chargées.
        var baseDir = AppContext.BaseDirectory;
        if (Directory.Exists(baseDir))
            foreach (var p in Directory.EnumerateFiles(baseDir, "*.dll")) paths.Add(p);
        _ = typeof(HttpClient); _ = typeof(Process); _ = typeof(Regex); _ = typeof(Enumerable);
        foreach (var a in AppDomain.CurrentDomain.GetAssemblies())
            if (!a.IsDynamic && a.Location.Length > 0) paths.Add(a.Location);

        // Une seule référence par nom d'assembly (sinon Roslyn signale des doublons, erreur CS1703).
        var byName = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var p in paths)
        {
            try
            {
                var name = AssemblyName.GetAssemblyName(p).Name; // lève une exception pour les DLL natives
                if (name is not null) byName.TryAdd(name, p);
            }
            catch { /* pas un assembly .NET */ }
        }
        _references = byName.Values.Select(p => (MetadataReference)MetadataReference.CreateFromFile(p)).ToList();
        return _references;
    }

    private static bool IsComplete(string code) =>
        SyntaxFactory.IsCompleteSubmission(SyntaxFactory.ParseSyntaxTree(code, CSharpParseOptions.Default.WithKind(SourceCodeKind.Script)));

    private static string Format(object? value) => value is null ? "null" : CSharpObjectFormatter.Instance.FormatObject(value);

    internal static void WriteColor(string text, ConsoleColor color, bool newLine = true)
    {
        var old = Console.ForegroundColor;
        Console.ForegroundColor = color;
        if (newLine) Console.WriteLine(text); else Console.Write(text);
        Console.ForegroundColor = old;
    }

    private static void PrintHelp()
    {
        Console.WriteLine("""
            Utilisation dans la console :
              <code C#>            exécuté directement, les variables sont gardées d'une ligne à l'autre
                                   (plusieurs lignes : continue tant que l'instruction n'est pas finie, ligne vide = exécuter)
              !<commande>          exécute une commande cmd (ex. !dir, !ipconfig, !cd C:\Projets)
              :cmd / :cs           passe en mode cmd (toutes les lignes) / revient au mode C#
              :run fichier         exécute un script .csx (C#) ou .bat/.cmd
              :vars                liste les variables C#
              :reset               efface les variables C#
              :clear               efface l'écran
              :exit                quitte
              Ctrl+C               interrompt le code en cours

            Dans le code C# :
              Cmd("dir")           renvoie la sortie d'une commande cmd (string)
              Sh("ping 8.8.8.8")   affiche la sortie en direct, renvoie le code de sortie
              Cd(@"C:\Projets")    change le dossier courant
              #r "chemin.dll"      charge une DLL ; #load "autre.csx" inclut un script

            En ligne de commande :
              CsConsole.exe                      console interactive
              CsConsole.exe script.csx [args]    exécute un script (args dans la variable Args)
              CsConsole.exe -c "Console.WriteLine(1+1);"
              CsConsole.exe -cmd "dir /b"
            """);
    }
}
