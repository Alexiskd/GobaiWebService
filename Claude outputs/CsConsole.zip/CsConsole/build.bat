@echo off
chcp 65001 >nul
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo Le SDK .NET 8 est requis pour compiler. Installe-le avec :
  echo     winget install Microsoft.DotNet.SDK.8
  echo puis relance build.bat.
  pause
  exit /b 1
)
dotnet publish CsConsole.csproj -c Release -o publish
if errorlevel 1 (
  echo.
  echo La compilation a echoue.
  pause
  exit /b 1
)
echo.
echo Termine : %~dp0publish\CsConsole.exe
pause
