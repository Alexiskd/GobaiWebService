// Exemple de script : CsConsole.exe exemple.csx
var fichiers = Directory.GetFiles(Environment.CurrentDirectory);
Console.WriteLine($"{fichiers.Length} fichier(s) dans {Environment.CurrentDirectory}");

// Commande cmd depuis le C# : Cmd() renvoie la sortie, Sh() l'affiche en direct et renvoie le code de sortie.
var version = Cmd("ver").Trim();
Console.WriteLine($"Windows : {version}");
Sh("echo Bonjour depuis cmd");

DateTime.Now
